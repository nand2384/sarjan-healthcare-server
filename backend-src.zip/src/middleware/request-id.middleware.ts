import { NextFunction, Request, Response } from "express";
import { v4 as uuid } from "uuid";

export function requestIdMiddleware(req: Request, res: Response, next: NextFunction): void {
    req.requestId = uuid();

    res.setHeader("X-Request-Id", req.requestId);

    next();
}
