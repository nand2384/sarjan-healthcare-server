import { Patient, Appointment, Queue } from "@generated/prisma/client";
import { RegisterAndBookResponseDto } from "./patient.dtos";

export class PatientMapper {
    public static toRegisterAndBookResponse(
        patient: Patient,
        appointment: Appointment,
        queue: Queue | null
    ): RegisterAndBookResponseDto {
        return {
            patient_id: patient.patient_id,
            uhid: patient.uhid,
            first_name: patient.first_name,
            last_name: patient.last_name,
            appointment_id: appointment.appointment_id,
            appointment_status_id: appointment.appointment_status_id,
            queue_number: queue ? queue.queue_number : null,
        };
    }
}
