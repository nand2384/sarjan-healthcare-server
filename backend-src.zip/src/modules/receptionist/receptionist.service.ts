import { AppError, ErrorCode } from "@errors";
import { ReceptionistRepository } from "./receptionist.repository";

export class ReceptionistService {
    constructor(private readonly receptionistRepository: ReceptionistRepository) {}

    public async getDashboardData() {
        const today = new Date();
        today.setUTCHours(0, 0, 0, 0);

        const tomorrow = new Date(today);
        tomorrow.setDate(tomorrow.getDate() + 1);

        const doctors = await this.receptionistRepository.getDoctorsInOpd(today, tomorrow);
        const upcomingAppointments = await this.receptionistRepository.getUpcomingAppointments(today, tomorrow);
        const stats = await this.receptionistRepository.getDailyStats(today, tomorrow);

        return {
            doctors,
            upcomingAppointments,
            stats
        };
    }

    public async getDoctorDashboardData(doctorId: number) {
        const today = new Date();
        today.setUTCHours(0, 0, 0, 0);

        const tomorrow = new Date(today);
        tomorrow.setDate(tomorrow.getDate() + 1);

        const doctor = await this.receptionistRepository.getDoctorWithAppointments(doctorId, today, tomorrow);
        const upcomingAppointments = await this.receptionistRepository.getUpcomingAppointments(today, tomorrow, doctorId);

        return {
            doctor,
            upcomingAppointments
        };
    }

    public async checkInPatient(appointmentId: number, createdByStaffId: number) {
        return this.receptionistRepository.checkInPatientTx(appointmentId, createdByStaffId);
    }

    public async updateAppointmentStatus(appointmentId: number, statusName: string, staffId: number) {
        const statusMap: Record<string, number> = {
            'waiting': 5,            // CHECKED_IN
            'in-consultation': 12,   // IN_CONSULTATION
            'waiting-reports': 13,   // WAITING_REPORTS
            'awaiting-payment': 14,  // AWAITING_PAYMENT
            'completed': 6,          // COMPLETED
            'walked-out': 15,        // WALKED_OUT
            'cancelled': 7           // CANCELLED
        };

        const targetStatusId = statusMap[statusName];
        if (!targetStatusId) throw new AppError(400, ErrorCode.BAD_REQUEST, "Invalid status");

        return this.receptionistRepository.updateAppointmentStatusTx(appointmentId, targetStatusId, statusName, staffId);
    }

}
