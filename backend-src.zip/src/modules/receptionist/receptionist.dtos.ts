import { z } from "zod";
import { updateAppointmentStatusSchema } from "./receptionist.schema";

export type UpdateAppointmentStatusDto = z.infer<typeof updateAppointmentStatusSchema>;
